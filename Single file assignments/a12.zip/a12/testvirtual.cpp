/*
    CH-230-A by Dr. Kinga Lipskoch
    Name: Sanjay Timilsena
    Username: stimilsena
    Mail: s.timilsena@jacobs-university.de
    Problem: a12_p8
*/

#include <iostream>
using namespace std;
#include "Area.h"
#include "Circle.h"
#include "Ring.h"
#include "Rectangle.h"
#include "Square.h"
 
const int num_obj = 7;
int main() {
	Area *list[num_obj];						// creating pointer array of object of Area class
	int index = 0;								// initializing index
	double sum_area = 0.0;						// initializing sum of area
	double sum_per = 0.0;
	cout << "Creating Ring: ";
	Ring blue_ring("BLUE", 5, 2);				// blue ring constructor
	cout << "Creating Circle: ";
	Circle yellow_circle("YELLOW", 7);
	cout << "Creating Rectangle: ";
	Rectangle green_rectangle("GREEN",5,6);
	cout << "Creating Circle: ";
	Circle red_circle("RED", 8);
	cout << "Creating Rectangle: ";
	Rectangle black_rectangle("BLACK", 10, 20);
	cout << "Creating Ring: ";
	Ring violet_ring("VIOLET", 100, 5);
  cout << "Creating Square: ";
  Square red_square("RED", 15);
	list[0] = &blue_ring;						// initialization of list
	list[1] = &yellow_circle;
	list[2] = &green_rectangle;
	list[3] = &red_circle;
	list[4] = &black_rectangle;
	list[5] = &violet_ring;
  list[6] = &red_square;
	while (index < num_obj) {					// Loop for going through every obj
		(list[index])->getColor();				
		double area = list[index]->calcArea();// Calculating area of every object
		double perimeter = list[index]->calcPer();// Calculating perimeter of every object
		cout << perimeter << endl;
		sum_per += perimeter;
		sum_area += area;
		index++;
	}
	cout << "\nThe total area is "
			<< sum_area << " units " << endl;	// Prinitng total sum
	cout << "\nThe total perimeter is " << sum_per << endl;
	return 0;
}

/* 				--------------------- The Class Relations ----------------------

                                             +----+
                                             |Area+-----------------------------+
                                             +-+--+                             |
                                               |                                |
           +--+                                |                                |
           |              +--------------------+----------------+               |
           |              +                                     +               |
           |            Circle                              Rectangle           |
Subclasses |              +                                                     |
           |              |                                                     |
           |              |                                                     |
           |              +                                                     |
           |            Ring                                                    |
           |                                                                    |  +-----+
           +--+                                area   <-------------------------+        |
                                                                                |        |
                                                                                |        |  Properties
                                                                                |        |
                                              color   <-------------------------+        |
                                                                                         |
                                                +                                  +-----+
                                                |
                                                |
                                                |
            +------------------+---------------------------------+---------------+
            |                  |                |                |               |
            |                  |                |                |               |
            |                  |                |                |               |
            |                  |                |                |               |
            +                  +                +                +               +
           Blue             Yellow            Green            Black           Violet

*/